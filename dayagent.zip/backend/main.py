import os
import json
import httpx
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
import anthropic

app = FastAPI(title="DayAgent API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000"],
    allow_methods=["*"],
    allow_headers=["*"],
)

anthropic_client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
GOOGLE_API_KEY = os.environ["GOOGLE_API_KEY"]
BESTTIME_API_KEY = os.environ.get("BESTTIME_API_KEY", "")  # optional


# ---------- Request/Response models ----------

class PlanRequest(BaseModel):
    message: str
    location: str  # e.g. "Seattle, WA"
    date: str      # e.g. "2025-05-10"


class Stop(BaseModel):
    name: str
    address: str
    place_id: str
    lat: float
    lng: float
    arrival_time: str
    duration_minutes: int
    travel_time_from_prev: Optional[int] = None
    notes: str
    category: str


class ItineraryResponse(BaseModel):
    stops: list[Stop]
    summary: str
    reasoning: str
    warnings: list[str]


# ---------- Tool implementations ----------

async def search_places(query: str, location: str, radius_meters: int = 10000) -> dict:
    """Search Google Places for venues matching the query near location."""
    url = "https://maps.googleapis.com/maps/api/place/textsearch/json"
    params = {
        "query": f"{query} near {location}",
        "key": GOOGLE_API_KEY,
        "radius": radius_meters,
    }
    async with httpx.AsyncClient() as client:
        resp = await client.get(url, params=params, timeout=10)
        data = resp.json()

    if data.get("status") not in ("OK", "ZERO_RESULTS"):
        return {"error": data.get("status"), "results": []}

    results = []
    for p in data.get("results", [])[:5]:
        results.append({
            "name": p.get("name"),
            "address": p.get("formatted_address"),
            "place_id": p.get("place_id"),
            "lat": p["geometry"]["location"]["lat"],
            "lng": p["geometry"]["location"]["lng"],
            "rating": p.get("rating"),
            "user_ratings_total": p.get("user_ratings_total"),
            "types": p.get("types", []),
            "open_now": p.get("opening_hours", {}).get("open_now"),
        })
    return {"results": results}


async def get_place_details(place_id: str) -> dict:
    """Get opening hours, phone, website for a specific place."""
    url = "https://maps.googleapis.com/maps/api/place/details/json"
    params = {
        "place_id": place_id,
        "fields": "name,formatted_address,opening_hours,formatted_phone_number,website,rating,price_level,geometry",
        "key": GOOGLE_API_KEY,
    }
    async with httpx.AsyncClient() as client:
        resp = await client.get(url, params=params, timeout=10)
        data = resp.json()

    if data.get("status") != "OK":
        return {"error": data.get("status")}

    r = data["result"]
    hours = r.get("opening_hours", {})
    return {
        "name": r.get("name"),
        "address": r.get("formatted_address"),
        "phone": r.get("formatted_phone_number"),
        "website": r.get("website"),
        "rating": r.get("rating"),
        "price_level": r.get("price_level"),
        "lat": r["geometry"]["location"]["lat"],
        "lng": r["geometry"]["location"]["lng"],
        "open_now": hours.get("open_now"),
        "weekday_text": hours.get("weekday_text", []),  # e.g. "Monday: 9:00 AM – 9:00 PM"
    }


async def get_directions(
    origin_lat: float,
    origin_lng: float,
    dest_lat: float,
    dest_lng: float,
    departure_time: str,  # ISO datetime string, e.g. "2025-05-10T14:00:00"
    mode: str = "driving",
) -> dict:
    """Get travel time and distance between two coordinates with traffic."""
    from datetime import datetime
    import time

    url = "https://maps.googleapis.com/maps/api/directions/json"

    # Convert ISO string to unix timestamp for departure_time
    try:
        dt = datetime.fromisoformat(departure_time)
        dep_unix = int(dt.timestamp())
    except Exception:
        dep_unix = int(time.time()) + 3600

    params = {
        "origin": f"{origin_lat},{origin_lng}",
        "destination": f"{dest_lat},{dest_lng}",
        "mode": mode,
        "departure_time": dep_unix,
        "traffic_model": "best_guess",
        "key": GOOGLE_API_KEY,
    }
    async with httpx.AsyncClient() as client:
        resp = await client.get(url, params=params, timeout=10)
        data = resp.json()

    if data.get("status") != "OK" or not data.get("routes"):
        return {"error": data.get("status", "NO_ROUTES")}

    leg = data["routes"][0]["legs"][0]
    return {
        "distance_km": round(leg["distance"]["value"] / 1000, 1),
        "duration_minutes": round(leg["duration"]["value"] / 60),
        "duration_in_traffic_minutes": round(
            leg.get("duration_in_traffic", leg["duration"])["value"] / 60
        ),
        "summary": data["routes"][0].get("summary", ""),
    }


async def get_weather(lat: float, lng: float, date: str) -> dict:
    """Get hourly weather forecast for a location on a specific date. Free, no API key."""
    url = "https://api.open-meteo.com/v1/forecast"
    params = {
        "latitude": lat,
        "longitude": lng,
        "hourly": "temperature_2m,precipitation_probability,weathercode",
        "temperature_unit": "fahrenheit",
        "start_date": date,
        "end_date": date,
        "timezone": "auto",
    }
    async with httpx.AsyncClient() as client:
        resp = await client.get(url, params=params, timeout=10)
        data = resp.json()

    hourly = data.get("hourly", {})
    times = hourly.get("time", [])
    temps = hourly.get("temperature_2m", [])
    precip = hourly.get("precipitation_probability", [])
    codes = hourly.get("weathercode", [])

    # Return a summary per hour (6am-10pm only)
    forecast = []
    for i, t in enumerate(times):
        hour = int(t.split("T")[1].split(":")[0])
        if 6 <= hour <= 22:
            wcode = codes[i] if i < len(codes) else 0
            condition = _weathercode_to_label(wcode)
            forecast.append({
                "time": t,
                "hour": hour,
                "temp_f": temps[i] if i < len(temps) else None,
                "precip_pct": precip[i] if i < len(precip) else None,
                "condition": condition,
            })
    return {"forecast": forecast, "timezone": data.get("timezone")}


def _weathercode_to_label(code: int) -> str:
    if code == 0: return "Clear"
    if code in (1, 2, 3): return "Partly cloudy"
    if code in (45, 48): return "Foggy"
    if code in (51, 53, 55): return "Drizzle"
    if code in (61, 63, 65): return "Rain"
    if code in (71, 73, 75): return "Snow"
    if code in (80, 81, 82): return "Rain showers"
    if code in (95, 96, 99): return "Thunderstorm"
    return "Unknown"


async def get_busyness(place_id: str, venue_name: str, address: str, day_of_week: int) -> dict:
    """
    Get hourly busyness forecast for a venue.
    Uses BestTime.app if API key is set, otherwise returns a heuristic estimate
    based on venue type and day so the agent can still reason about crowd levels.
    day_of_week: 0=Monday ... 6=Sunday
    """
    if BESTTIME_API_KEY:
        try:
            async with httpx.AsyncClient() as client:
                # BestTime: first create a forecast (or fetch existing)
                resp = await client.post(
                    "https://besttime.app/api/v1/forecasts",
                    params={"api_key_private": BESTTIME_API_KEY},
                    json={"venue_name": venue_name, "venue_address": address},
                    timeout=15,
                )
                data = resp.json()
            day_data = data.get("analysis", [{}] * 7)[day_of_week]
            hours = day_data.get("day_raw", [])
            return {
                "source": "besttime",
                "hourly_busyness": [
                    {"hour": i + 6, "busyness_pct": hours[i] if i < len(hours) else None}
                    for i in range(17)  # 6am-10pm
                ],
            }
        except Exception:
            pass  # Fall through to heuristic

    # Heuristic fallback — agent will explain this in its reasoning
    day_name = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"][day_of_week]
    return {
        "source": "heuristic",
        "note": (
            f"No live busyness data available for {venue_name}. "
            f"As a general rule: restaurants peak Fri/Sat 6–8pm; "
            f"parks peak Sat/Sun 11am–3pm; "
            f"grocery stores peak weekdays 5–7pm and weekends 10am–1pm. "
            f"Today is {day_name}."
        ),
    }


# ---------- Tool definitions for Claude ----------

TOOLS = [
    {
        "name": "search_places",
        "description": (
            "Search for places/venues matching a query near a city or address. "
            "Use this to find parks, restaurants, concert venues, grocery stores, etc. "
            "Returns up to 5 results with name, address, place_id, coordinates, and rating."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search query, e.g. 'Thai restaurant', 'public park', 'Whole Foods'"},
                "location": {"type": "string", "description": "City or area to search near, e.g. 'Seattle, WA'"},
                "radius_meters": {"type": "integer", "description": "Search radius in meters, default 10000", "default": 10000},
            },
            "required": ["query", "location"],
        },
    },
    {
        "name": "get_place_details",
        "description": (
            "Get detailed info about a specific place using its place_id from search_places. "
            "Returns opening hours (weekday_text), phone, website, price level, and exact coordinates."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "place_id": {"type": "string", "description": "Google Place ID from search_places results"},
            },
            "required": ["place_id"],
        },
    },
    {
        "name": "get_directions",
        "description": (
            "Get driving/walking travel time between two coordinates, accounting for real-time traffic. "
            "Use this to calculate how long it takes to get from one stop to the next."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "origin_lat": {"type": "number"},
                "origin_lng": {"type": "number"},
                "dest_lat": {"type": "number"},
                "dest_lng": {"type": "number"},
                "departure_time": {"type": "string", "description": "ISO datetime when you'd depart, e.g. '2025-05-10T14:00:00'"},
                "mode": {"type": "string", "enum": ["driving", "walking", "transit"], "default": "driving"},
            },
            "required": ["origin_lat", "origin_lng", "dest_lat", "dest_lng", "departure_time"],
        },
    },
    {
        "name": "get_weather",
        "description": (
            "Get hourly weather forecast for a location on the trip date. "
            "Use this to warn about rain or adjust outdoor activity timing."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "lat": {"type": "number"},
                "lng": {"type": "number"},
                "date": {"type": "string", "description": "Date in YYYY-MM-DD format"},
            },
            "required": ["lat", "lng", "date"],
        },
    },
    {
        "name": "get_busyness",
        "description": (
            "Get an hourly busyness/crowd forecast for a venue on a given day. "
            "Use this to avoid peak times, especially for restaurants without reservations. "
            "Returns either live BestTime data or a heuristic estimate with reasoning."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "place_id": {"type": "string"},
                "venue_name": {"type": "string"},
                "address": {"type": "string"},
                "day_of_week": {"type": "integer", "description": "0=Monday, 6=Sunday"},
            },
            "required": ["place_id", "venue_name", "address", "day_of_week"],
        },
    },
]


# ---------- Tool dispatcher ----------

async def dispatch_tool(tool_name: str, tool_input: dict) -> str:
    try:
        if tool_name == "search_places":
            result = await search_places(**tool_input)
        elif tool_name == "get_place_details":
            result = await get_place_details(**tool_input)
        elif tool_name == "get_directions":
            result = await get_directions(**tool_input)
        elif tool_name == "get_weather":
            result = await get_weather(**tool_input)
        elif tool_name == "get_busyness":
            result = await get_busyness(**tool_input)
        else:
            result = {"error": f"Unknown tool: {tool_name}"}
    except Exception as e:
        result = {"error": str(e)}
    return json.dumps(result)


# ---------- Agent loop ----------

SYSTEM_PROMPT = """You are DayAgent, an expert daily itinerary planner.

Your job is to take a user's list of things they want to do and create an optimized, time-aware schedule for a single day.

## How to plan
1. Search for each requested activity/venue using search_places.
2. Get details (hours, closing time) for candidate venues using get_place_details.
3. Get weather for the trip location and date.
4. Get busyness estimates for restaurants or busy venues.
5. Calculate travel times between stops using get_directions.
6. Reason about the optimal order: minimize total travel time, avoid peak crowds, respect opening hours.
7. If a constraint can't be met (e.g. restaurant is closed), explain why and suggest an alternative.

## Output format
After all tool calls, return ONLY valid JSON matching this exact schema:
{
  "stops": [
    {
      "name": "string",
      "address": "string",
      "place_id": "string",
      "lat": number,
      "lng": number,
      "arrival_time": "HH:MM",
      "duration_minutes": number,
      "travel_time_from_prev": number or null,
      "notes": "string (1-2 sentences explaining why this time)",
      "category": "restaurant|park|entertainment|shopping|other"
    }
  ],
  "summary": "1-sentence overall summary",
  "reasoning": "2-3 sentences explaining key decisions (traffic, busyness, weather)",
  "warnings": ["array of any issues or trade-offs the user should know"]
}

Be specific about times. Default start time is 10:00 AM unless the user specifies otherwise.
Return ONLY the JSON — no markdown, no explanation before or after."""


async def run_agent(message: str, location: str, date: str) -> dict:
    user_content = f"""Plan my day in {location} on {date}.

What I want to do: {message}

Create an optimized itinerary that minimizes travel time, avoids crowds where possible, and respects opening hours."""

    messages = [{"role": "user", "content": user_content}]

    # Agentic loop — keep going until Claude stops calling tools
    for _ in range(10):  # max 10 iterations as a safety guard
        response = anthropic_client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=4096,
            system=SYSTEM_PROMPT,
            tools=TOOLS,
            messages=messages,
        )

        # Append assistant response to history
        messages.append({"role": "assistant", "content": response.content})

        if response.stop_reason == "end_turn":
            # Extract the JSON from the final text block
            for block in response.content:
                if hasattr(block, "text"):
                    try:
                        return json.loads(block.text)
                    except json.JSONDecodeError:
                        # Try to extract JSON from within text
                        import re
                        match = re.search(r'\{[\s\S]+\}', block.text)
                        if match:
                            return json.loads(match.group())
            raise ValueError("Agent returned no parseable JSON")

        if response.stop_reason != "tool_use":
            break

        # Execute all tool calls in this response
        tool_results = []
        for block in response.content:
            if block.type == "tool_use":
                result_str = await dispatch_tool(block.name, block.input)
                tool_results.append({
                    "type": "tool_result",
                    "tool_use_id": block.id,
                    "content": result_str,
                })

        messages.append({"role": "user", "content": tool_results})

    raise ValueError("Agent did not complete within iteration limit")


# ---------- Routes ----------

@app.get("/health")
async def health():
    return {"status": "ok"}


@app.post("/plan", response_model=ItineraryResponse)
async def plan_day(req: PlanRequest):
    try:
        result = await run_agent(req.message, req.location, req.date)
        return ItineraryResponse(**result)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
