import type { Itinerary, Stop } from "../types"

const CATEGORY_EMOJI: Record<Stop["category"], string> = {
  restaurant: "🍽",
  park: "🌳",
  entertainment: "🎵",
  shopping: "🛒",
  other: "📍",
}

const CATEGORY_COLOR: Record<Stop["category"], string> = {
  restaurant: "#f97316",
  park: "#22c55e",
  entertainment: "#a855f7",
  shopping: "#3b82f6",
  other: "#6b7280",
}

interface Props {
  itinerary: Itinerary
  activeIndex: number | null
  onSelectStop: (index: number) => void
}

export function Timeline({ itinerary, activeIndex, onSelectStop }: Props) {
  return (
    <div className="timeline">
      <div className="timeline-header">
        <h2>Your Day</h2>
        <p className="summary">{itinerary.summary}</p>
      </div>

      {itinerary.warnings.length > 0 && (
        <div className="warnings">
          {itinerary.warnings.map((w, i) => (
            <div key={i} className="warning-item">⚠️ {w}</div>
          ))}
        </div>
      )}

      <div className="stops">
        {itinerary.stops.map((stop, i) => (
          <div key={stop.place_id + i}>
            {stop.travel_time_from_prev != null && (
              <div className="travel-gap">
                <span className="travel-line" />
                <span className="travel-label">🚗 {stop.travel_time_from_prev} min drive</span>
                <span className="travel-line" />
              </div>
            )}

            <div
              className={`stop-card ${activeIndex === i ? "active" : ""}`}
              onClick={() => onSelectStop(i)}
              style={{ "--accent": CATEGORY_COLOR[stop.category] } as React.CSSProperties}
            >
              <div className="stop-time">{stop.arrival_time}</div>
              <div className="stop-body">
                <div className="stop-title">
                  <span className="stop-emoji">{CATEGORY_EMOJI[stop.category]}</span>
                  <span>{stop.name}</span>
                </div>
                <div className="stop-address">{stop.address}</div>
                <div className="stop-duration">{stop.duration_minutes} min</div>
                <div className="stop-notes">{stop.notes}</div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="reasoning-box">
        <h3>Agent reasoning</h3>
        <p>{itinerary.reasoning}</p>
      </div>
    </div>
  )
}
