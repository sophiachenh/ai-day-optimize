import { useState } from "react"
import type { PlanRequest } from "../types"

interface Props {
  onSubmit: (req: PlanRequest) => void
  loading: boolean
}

export function PlanForm({ onSubmit, loading }: Props) {
  const today = new Date().toISOString().split("T")[0]
  const [message, setMessage] = useState("")
  const [location, setLocation] = useState("")
  const [date, setDate] = useState(today)

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!message.trim() || !location.trim()) return
    onSubmit({ message, location, date })
  }

  return (
    <form onSubmit={handleSubmit} className="plan-form">
      <div className="field">
        <label htmlFor="location">📍 City / neighborhood</label>
        <input
          id="location"
          type="text"
          placeholder="Seattle, WA"
          value={location}
          onChange={e => setLocation(e.target.value)}
          required
        />
      </div>

      <div className="field">
        <label htmlFor="date">📅 Date</label>
        <input
          id="date"
          type="date"
          value={date}
          min={today}
          onChange={e => setDate(e.target.value)}
          required
        />
      </div>

      <div className="field">
        <label htmlFor="message">🗓 What do you want to do?</label>
        <textarea
          id="message"
          rows={4}
          placeholder={
            "e.g. Go to a park in the morning, get Thai food for lunch (no reservation), " +
            "see a live music show in the evening, stop by a grocery store"
          }
          value={message}
          onChange={e => setMessage(e.target.value)}
          required
        />
      </div>

      <button type="submit" disabled={loading || !message.trim() || !location.trim()}>
        {loading ? (
          <span className="loading-text">
            <span className="spinner" /> Planning your day…
          </span>
        ) : (
          "Plan my day →"
        )}
      </button>

      {loading && (
        <p className="loading-hint">
          The agent is searching for venues, checking hours, and calculating routes.
          This takes about 15–30 seconds.
        </p>
      )}
    </form>
  )
}
